
<x-jet-nav-link class="text-amber-300  hover:text-amber-200  hover:border-amber-300" href="{{ route('maintenance.storing') }}"
:active="request()->routeIs('maintenance.storing')">
Storing meldingen 
</x-jet-nav-link>