
 <x-app-layout>
    <div class=" text-2xl font-sans text-amber-300 shadow-lg bg-gray-800 rounded-3xl pt-10 pb-10 m-auto my-5 h-3/4 text-center shadow-amber-300 w-6/12">
        <h1>Welkom op het dashboard van finance.</h1><br/>

     
     
     
     
     
        </div>


</x-app-layout>
