
 <x-app-layout>
    <div class=" text-2xl font-sans text-amber-300 shadow-lg bg-gray-800 rounded-3xl pt-10 pb-10 m-auto my-5 h-3/4 text-center shadow-amber-300 w-6/12">
        <h1>Welkom op het dashboard van maintenance.</h1><br/>
        <a href="/maintenance/storing" class="inline-flex items-center py-2 px-3 text-sm font-medium text-center text-gray-800 bg-blue-700 rounded-lg hover:bg-amber-300 focus:ring-4 focus:outline-none focus:ring-amber-300 dark:bg-amber-300 dark:hover:bg-amber-300 dark:focus:ring-amber-300">
           Storingen overzicht
       </a>
        </div>
</x-app-layout>
